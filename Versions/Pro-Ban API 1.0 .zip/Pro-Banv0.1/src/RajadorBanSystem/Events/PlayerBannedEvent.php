<?php

namespace RajadorBanSystem\Events;

/*
  
  Rajador Developer

  ▒█▀▀█ ░█▀▀█ ░░░▒█ ░█▀▀█ ▒█▀▀▄ ▒█▀▀▀█ ▒█▀▀█ 
  ▒█▄▄▀ ▒█▄▄█ ░▄░▒█ ▒█▄▄█ ▒█░▒█ ▒█░░▒█ ▒█▄▄▀ 
  ▒█░▒█ ▒█░▒█ ▒█▄▄█ ▒█░▒█ ▒█▄▄▀ ▒█▄▄▄█ ▒█░▒█

  GitHub: https://github.com/RajadorDev

  Discord: Rajador#7070


*/


class PlayerBannedEvent extends PunishEvent 
{
	
	public static $handlerList = null;
	
	public function getEventId() : int 
	{
		return \RajadorBanSystem\ProBan::PLAYER_BANNED_EVENT;
	}
	
}