# ProBan Plugin ⚖

Advanced punishment plugin, with WebHook Connection Discord

## Author:
- *Rajador Developer* 🤓👍
- [GitHub](https://github.com/RajadorDev) 🐙
- [Instagram](https://www.instagram.com/rajadortv/) 📷
- [Twiter](https://twitter.com/Rajadortv) 🐦
- [Discord](https://discord.io/Rajador) 👥

---

### How to use? :
- Put the Phar plugin in your PocketMine / Plugins folder
- You can edit the messages in the file `messages.yml`
- Configure according to your preferences in `config.yml`
- Configure the Discord Webhook system in `DiscordInfo.yml`
- To set your Webhook Discord use: */proban webhook {your_webhook}*

---

### Main Command:
- To Show plugin information: **/pb about**
- Set your webhook: **/pb webhook {webhook_url}**
- To see the list of bans: **/pb banlist {address/accounts}**
- To see information about a ban: **/pb seeban {player/address Banned}**


