<?php

namespace RajadorBanSystem\Events;

/*
  
  Rajador Developer

  ▒█▀▀█ ░█▀▀█ ░░░▒█ ░█▀▀█ ▒█▀▀▄ ▒█▀▀▀█ ▒█▀▀█ 
  ▒█▄▄▀ ▒█▄▄█ ░▄░▒█ ▒█▄▄█ ▒█░▒█ ▒█░░▒█ ▒█▄▄▀ 
  ▒█░▒█ ▒█░▒█ ▒█▄▄█ ▒█░▒█ ▒█▄▄▀ ▒█▄▄▄█ ▒█░▒█

  GitHub: https://github.com/RajadorDev

  Discord: Rajador#7070


*/

class PlayerExpelledEvent extends PunishEvent 
{
	
	public static $handlerList = null;
	
	public function getEventId() : int 
	{
		return \RajadorBanSystem\ProBan::PLAYER_EXPELL_EVENT;
	}
	
}